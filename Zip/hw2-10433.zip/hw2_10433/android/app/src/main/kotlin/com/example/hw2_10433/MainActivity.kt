package com.example.hw2_10433

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
